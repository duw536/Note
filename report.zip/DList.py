"""
이중 연결 리스트 (Doubly Linked List)
"""

#==============================================================================================================
class Node:
    def __init__(self, value):
        self.data = value
        self.next = None
        self.prev = None
    def __str__(self):
        return f"[{self.data}]"
#==============================================================================================================
class DList:
    def __init__(self):
        self.head = None    # 리스트의 첫 노드
        self.tail = None    # 리스트의 마지막 노드
        self.count = 0
    #--------------------------------------------------------------------------------
    # 리스트의 현재 상태를 출력한다.
    def show(self):
    # head ->[100]-[200]<-tail (2 nodes)    
        print("head ->", end="")
        current = self.head
        while current is not None:
            print(current, end="")
            current = current.next
            if current is not None:
                print("-",end="")
        print(f"<-tail({self.count} nodes)")
    #--------------------------------------------------------------------------------
    # 리스트의 맨 앞에 새 노드를 연결(추가)한다.
    def insertFront(self, newData):
        newNode = newData if isinstance (newData, Node) else (Node(newData))
        if self.head is None:
            self.head = newNode
            self.count = 1
        else:
            self.head.prev = newNode
            newNode.next = self.head
            self.head = newNode
            self.count += 1
    #--------------------------------------------------------------------------------
    # 리스트의 targetData 뒤에 newData를 삽입처리한다.
    def insertAfter(self, targetData, newData):
        # targetData를 노드로 표준화하기
        targetNode = targetData if isinstance(targetData, Node) else self.find(targetData)
        # newData를 노드로 표준화하기 
        newNode = newData if isinstance(newData, Node) else Node(newData)
        if targetNode is None or newNode is None:
            return
        #--------------------------------------------------------------------------------
        
    #--------------------------------------------------------------------------------
    # 리스트의 targetData 앞에 newData를 삽입처리한다.
    def insertBefore(self, targetData, newData):
        # targetData를 노드로 표준화하기
        targetNode = targetData if isinstance(targetData, Node) else self.find(targetData)
        # newData를 노드로 표준화하기 
        newNode = newData if isinstance(newData, Node) else Node(newData)
        if targetNode is None or newNode is None:
            return
        #--------------------------------------------------------------------------------
        if self.head is targetNode:
            self.insertFront(newNode)
        else:
            newNode.prev = targetNode.prev
            newNode.next = targetNode
            targetNode.prev.next = newNode
            targetNode.prev = newNode
            self.count += 1            

    #--------------------------------------------------------------------------------
    # 리스트에서 특정 값(value을 가진 노드를 찾아 반환한다. (없으면 None 반환)
    def find(self, value):
        current = self.head
        while current:
            if current.data == value:
                return current
            else:
                current = current.next
        return None
    #--------------------------------------------------------------------------------
    # 리스트의 맨 뒤에 새 노드를 연결(추가)한다.
    def append(self, newData):
        newNode = newData if isinstance (newData, Node) else (Node(newData))

        # 빈 리스트 처음 append하는 경우 먼저 처리
        if self.count == 0:
            self.head = newNode
            self.tail = newNode
        else:   # 리스트의 1개 이상의 노드가 있을 경우
            self.tail.next = newNode    
            newNode.prev = self.tail
            self.tail = newNode
        self.count += 1
    #--------------------------------------------------------------------------------

#==============================================================================================================

dlist = DList()
dlist.append(300)
dlist.show()
dlist.append(500)
dlist.show()
dlist.insertFront(200)
dlist.show()
dlist.insertFront(100)
dlist.show()
print(dlist.find(300))
print(dlist.find(1300))
dlist.insertBefore(500, 400)
dlist.show()
