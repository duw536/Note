"""
파이썬 객체는 생성된 후에도 객체별로 속성 추가가 가능하다.
"""

class Point: 
    instanceCount = 0 # Class Point로 생성된 객체(인스턴스) 개수를 관리한다.
    instanceList = [] # class Point로 생성된 객체(안스턴스)들을 모두 모아 둔다.
    def __init__(self, x, y):
        self.x = x
        self.y = y
        Point.instanceCount += 1 # 클래스 변수는 클래스 이름으로 접근해야 한다.
        print(f"지금까지 point가 {Point.instanceCount}개 생성되었습니다.")
        Point.instanceList.append(self)

    def __str__(self):
        return f"({self.x}, {self.y})"
    
    def show(self):
        print(f"({self.x}, {self.y})")
#------------------------------------
p1 = Point(3, 4) 
p2 = Point(4, 4)
p3 = Point(5, 4)
p1.instanceList.clear()

# print(f"p1 = {p1}")

for aPoint in Point.instanceList:
    print(aPoint)
# p1.show()
# p2 = Point(5, 6)
# print(p1.x, p1.y)
# print(p2.x, p2.y)
# # 후천성 속성 추가
# p1.z = 100
# print(p1.x, p1.y, p1.z)
# del p1.z
# print(p1.x, p1.y)