#========================================================================================
# 단순 연결 리스트 (Singly Linked List)
#========================================================================================
class Node: 
    def __init__(self, value):
        self.data = value   # data 공간에 value 저장
        self.next = None    # 다음 연결 노드가 결정될 때까지는 None으로 초기화
    def __str__(self):
        return f"{self.data}->"
#========================================================================================
class SList:
    def __init__(self):
        self.head = None    # 단순 연결 리스트 생성 초기에는 오류가 없으므로 head -> None
        self.count = 0      # 리스트의 초기 노드 수는 0
        #--------------------------------------------------------------------------------
    def __len__(self):
        return self.count
        #--------------------------------------------------------------------------------
    def insertFront(self, newNode):
        if self.head is None:   # 리스트가 비어있으면 (지금 추가하려는 newNode가 첫 노드가 됨)
            self.head = newNode # 리스트의 헤드는 newNode를 가리킨다.
            self.count = 1
        else:                   # 리스트에 노드가 1개 이상 연결되어 있는 경우
            newNode.next = self.head    # newNode가 기존 리스트의 첫 노드로 연결된다.
            self.head = newNode         # 리스트의 head 속성을 newNode로 갱신한다.
            self.count += 1
    #--------------------------------------------------------------------------------
    # 리스트의 지정된 위치(노드, 데이터) 앞에 새 노드(노드, 데이터)를 삽입한다.
    def insertBefore(self, targetData, newData):
        # targetData를 노드로 표준화하기
        targetNode = targetData if isinstance(targetData, Node) else self.find(targetData)
        # newData를 노드로 표준화하기 
        newNode = newData if isinstance(newData, Node) else Node(newData)
        #--------------------------------------------------------------------------------
        # 정상적인 삽입 연산이 불가능한 조건 먼저 정리하기
        #--------------------------------------------------------------------------------
        if targetNode is None or newNode is None:
            return 
        #--------------------------------------------------------------------------------
        # targetNode와 newNode가 모두 None이 아닌 정상 노드인 상황에서 나머지 내용 구현 
        #--------------------------------------------------------------------------------
        # prevNode = None
        # current = self.head
        # while current: 
        #     prevNode = current
        #     current = current.next
        #     if current is targetNode:
        #         prevNode.next = newNode
        #         newNode.next = current
        # self.count += 1

        previous = None
        current = self.head
        # target을 찾는다.
        while current is not targetNode:
            previous = current
            current = current.next
        # targetNode가 첫 노드(head)인 경우
        if previous is None:
            newNode.next = self.head
            self.head = newNode
        else:
            newNode.next = current
            previous.next = newNode
        self.count += 1

    #--------------------------------------------------------------------------------
    # 리스트의 현재 상태를 출력한다.
    # head->[100]->[200]->None (2 nodes)
    def show(self):
        print("head->", end="")
        current = self.head     # 리스트의 첫 노드부터 차레로 다음 노드로 따라갈 변수 current를 초기화
        while current is not None:
            print(current, end="")
            current = current.next
        print(f"None({self.count+1} nodes)")
    #--------------------------------------------------------------------------------
    # 리스트의 마지막에 새 노드를 연결한다.
    def append(self, newData):
        # 매개변수 newData가 Node 객체인지 아닌지 판단하여 newNode를 설정해준다.
        if isinstance(newData, Node):
            newNode = newData
        else:
            newNode = Node(newData)
        #--------------------------------------------------------------------------------
        # 위 if else 한줄
        # newNode = newData if isinstance(newData, Node(newData)) else Node(newData)
        #--------------------------------------------------------------------------------
        if self.head is None:   
            self.head = newNode
            self.count = 1
        else:
            current = self.head
            while current.next is not None:  # currnet 뒤에 이어지는 다른 노드가 있다면,
                current = current.next       # currnet는 다음 이어지는 노드로 이동한다.
                #   while 종료 후에는 currnet가 마지막 노드를 가리키게 된다. 
            current.next = newNode           # currnet(마지막 노드)뒤에 newNode를 연결한다.
        self.count += 1
    #--------------------------------------------------------------------------------
    def appendBackUp(self, newNode):
        if self.head is None:   
            self.head = newNode
            self.count = 1
        else:
            current = self.head
            while current.next is not None:  # currnet 뒤에 이어지는 다른 노드가 있다면,
                current = current.next       # currnet는 다음 이어지는 노드로 이동한다.
                #   while 종료 후에는 currnet가 마지막 노드를 가리키게 된다. 
            current.next = newNode           # currnet(마지막 노드)뒤에 newNode를 연결한다.
        self.count += 1
    #--------------------------------------------------------------------------------
    # 주어진 값을 가진 노드가 리스트에 있는지 확인한다.
    # 있으면 해당 노드를 반환, 없으면 None을 반환한다.
    def find(self, value):
        # 첫 노드부터 차례대로 value와 방문한 노드의 data 속성값을 비교한다.
        # 더 방문할 노드가 없을 때까지 방문한다.
        current = self.head                 # 첫 노드부터 시작한다.
        while current is not None:          # current가 None이 아니면 반복한다.
            if current.data == value:       
                return current
            else:
                current = current.next      # 다음 노드로 이동
        return None                         # while가 정상 종료되면 찾는 노드가 없다는 의미이므로 None 반환
    #--------------------------------------------------------------------------------
    # 리스트의 마지막 노드를 제거하고 제거한 노드의 값을 반환한다.
    # 직접 만들었던 예외처리 없는 pop
    # def pop(self):
    #     current = self.head
    #     prevNode = None
    #     while current.next is not None:
    #         prevNode = current
    #         current = current.next
    #         if current.next is None:
    #             prevNode.next = current.next
    #             self.count -= 1
    #             return current.data
    #     return None
            
    def pop(self):
        # 마지막 노드를 찾는다
        previous = None
        currnet = self.head
        while currnet:  # current가 None이 아닌 정상 노드이면
            if currnet.next is None:    # current 노드가 마지막 노드이면
                if previous is None:    # current 노드가 head인 경우(노드가 1개뿐인 리스트에 해당)
                    self.head = None
                else: 
                    previous.next = None
                self.count -= 1
                return currnet.data
            else: 
                previous = currnet
                currnet = currnet.next
        # 비어있는 리스트(empty list)인 경우 여기까지 도달함.
        return None
        #--------------------------------------------------------------------------------

    # 특정 노드를 지정하여 리스트에서 삭제한다. 
    # 반환값: 리스트에서 삭제된 노드를 반환한다.
    def remove(self, targetData):
        if isinstance(targetData, Node):
            targetNode = targetData
        else:
            targetNode = self.find(targetData)
        # 삭제 대상(targetNode)가 None인 경우
        if targetNode is None:
            return None
        # --------------------------------------------------------------------------------
        current = self.head
        previous = None     # previous는 currnet의 직전 방문 노드
        
        while current is not targetNode:
            previous = current
            current = current.next
        if previous is None:    # 첫 노드가 타겟 노드인 경우에 해당
            self.head = targetNode.next
            # self.head = self.head.next 위와 같음
        else:
            previous.next = current.next
            # previous.next = targetNode.next 위와 같음
        current.next = None # targetNode를 완전히 정리함
        self.count -= 1
        return current
#========================================================================================
n1 = Node(100)
slist = SList() # 비어있는 리스트 생성 
slist.show()
slist.insertFront(n1)
slist.show()
slist.append(200)
slist.show()
slist.insertFront(Node(300))
slist.show()
slist.insertFront(Node(400))
slist.show()
slist.insertFront(Node(500))
slist.show()
print(len(slist))
slist.append(Node(100))
slist.show()
print(slist.find(200))
print(slist.find(1200))
slist.remove(200)
slist.show()
print(slist.pop())
slist.show()
slist.insertBefore(400, 10)
slist.show()