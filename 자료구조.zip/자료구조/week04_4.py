"""
재귀함수 연습
"""
def fact(n):
    if n <= 1:
        return 1 # 무한 재귀호출 방지 조건
    return n*fact(n-1)
#--------------------------------------------
def fact2(n):
    result = 1
    for i in range(n, 1, -1):
        result *= i
    return result
#=======================================================
print(fact(5))
print(fact2(5))