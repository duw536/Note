# python comment
"""
asd
asdsfsa
adasf
"""
if 2 > 1:
    print("2는 1보다 크다")
    print("조건식이 참이다.")
else:
    print("1이 2보다 크다")
    print("조건식이 거짓이다.")
